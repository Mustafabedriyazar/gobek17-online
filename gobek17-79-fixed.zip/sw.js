var C="gobek17-79";
var A=["./","./index.html","./manifest.webmanifest","./icon-192.png","./icon-512.png"];
self.addEventListener("install",function(e){
  e.waitUntil(caches.open(C).then(function(c){return c.addAll(A)}).then(function(){return self.skipWaiting()}));
});
self.addEventListener("activate",function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.filter(function(k){return k!==C}).map(function(k){return caches.delete(k)}));
  }).then(function(){return self.clients.claim()}));
});
self.addEventListener("fetch",function(e){
  if(e.request.method!=="GET")return;
  var isDoc=e.request.mode==="navigate"||/index\.html$/.test(e.request.url);
  if(isDoc){
    e.respondWith(
      fetch(e.request).then(function(n){
        if(n&&n.ok){var cl=n.clone();caches.open(C).then(function(c){c.put(e.request,cl)})}
        return n;
      }).catch(function(){return caches.match(e.request,{ignoreSearch:true}).then(function(r){return r||caches.match("./index.html")})})
    );
    return;
  }
  e.respondWith(
    caches.match(e.request,{ignoreSearch:true}).then(function(r){
      if(r)return r;
      return fetch(e.request).then(function(n){
        if(n&&n.ok){var cl=n.clone();caches.open(C).then(function(c){c.put(e.request,cl)})}
        return n;
      });
    })
  );
});
